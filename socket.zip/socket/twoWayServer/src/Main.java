import java.io.*;
import java.net.*;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        BufferedReader in = null; // 입력 리더
        BufferedWriter out = null; // 출력 리더
        ServerSocket listener = null; // 서버 대기 socket 개체
        Socket socket = null; // 연결 처리 socket 개체
        Scanner scanner = new Scanner(System.in); // 입력 처리 개체
        try{
            listener = new ServerSocket(5000); // 5000포트로 현재 IP를 이용 서버 개체 생성
            System.out.println("서버 연결 대기 시작 ....... ");
            socket = listener.accept(); // 클라이언트로부터 연결 요청 처리 대기
            System.out.println("연결됨.");
            in = new BufferedReader(new InputStreamReader(socket.getInputStream())); // 입력 처리 개체
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())); // 출력 처리 개체
            while(true){
                String inMsg = in.readLine(); // 클라이언트로 부터 전달된 데이터 한줄 읽기.
                if(inMsg.equalsIgnoreCase("bye")){
                    System.out.println("클라이언트 연결 종료 요청....");
                    break;
                }
                System.out.println("클라이언트: " + inMsg);
                System.out.print("보내기>> ");
                String outMsg = scanner.nextLine(); // 보낼 데이터 입력 대기 처리
                out.write(outMsg + "\n"); // 키보드에서 입력된 데이터 클라이언트에 전송
                out.flush(); // out 스트림 버퍼에 있는 모든 문자열 비우기.
            }
        }catch(IOException ie){
            ie.printStackTrace();
        }finally {
            try{
                scanner.close();
                socket.close();
                listener.close();
            }catch(Exception ie){
                System.out.println(ie.getMessage());
            }
        }
    }
}