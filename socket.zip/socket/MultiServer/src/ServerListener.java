import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ServerListener extends Thread{
    ServerSocket serverSocket = null;
    int count = 1; // 클라이언트 연결 처리 갯수 카운트

    ServerListener(ServerSocket _serverSocket)
    {
        this.serverSocket = _serverSocket; // 서버 리스닝 개체 생성
        System.out.println(new SimpleDateFormat("[hh:mm:ss]").format(new Date()) + " Server Opened.");
    }
    @Override
    public void run()
    {
        try{
            while(true){
                Socket socket = serverSocket.accept(); // 클라이언트 연결 요청 승락
                System.out.println("Thread " + count + " is Started.");
                //클라이언트 연결 관리 쓰레드 개체 생성
                ClientConnectedThread cThread = new ClientConnectedThread(socket, count);
                cThread.start();
                count++;
            }
        }catch(IOException ie){
            System.out.println("Server Stop.(" + ie.getMessage() + ")");
        }
    }
}
