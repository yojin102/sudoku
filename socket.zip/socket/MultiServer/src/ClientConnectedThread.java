import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

public class ClientConnectedThread extends Thread{
    Socket socket;
    int id;
    ClientConnectedThread(Socket _socket, int _id){
        this.socket = _socket; // 클라이언트 연결 관리 개체 생성
        this.id = _id; // 담당 쓰레드 ID
    }

    public void run(){
        try{
            while(true){
                // 클라이언트 전송 데이터 처리 스트림 개체 생성 및 소켓 연결
                InputStream inStream = socket.getInputStream();
                byte[] buffer = new byte[256]; // 버퍼 정의 및 생성
                int size = inStream.read(buffer); // 클라이언트 전송 데이터 사이즈
                //클라이언트 전송데이터 "UTF-8" 인코딩 문자열 생성
                String outMsg = new String(buffer, 0, size, "UTF-8");
                System.out.println("Thread " + id + " >> " + outMsg);
            }
        }catch(IOException ie){
            System.out.println("Thread " + id + " : " + ie.getMessage());
        }
    }
}
