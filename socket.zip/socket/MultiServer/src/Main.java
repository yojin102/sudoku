import java.io.IOException;
import java.net.ServerSocket;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner inBreak = new Scanner(System.in);
        ServerSocket serverSocket = null;
        try{
            serverSocket = new ServerSocket(5000); // 서버 소켓 객체 생성(현 ip, 5000번 포트)
            ServerListener listener = new ServerListener(serverSocket); // 연결 처리 담당 쓰레드 개체 생성
            listener.start();
            System.out.println("서버 종료시 q를 누르세요.");
            while(true) {
                String temp = inBreak.next();
                if (temp.equalsIgnoreCase("q")) {
                    System.exit(0);
                    break;
                }
            }
        }catch(Exception ie){

        }
        finally {
            try {
                serverSocket.close();
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }
}