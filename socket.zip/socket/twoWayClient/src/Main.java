import java.io.*;
import java.net.*;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        BufferedReader in = null; // 입력 리더
        BufferedWriter out = null; // 출력 리더
        Socket socket = null;
        Scanner scanner = new Scanner(System.in);
        try{
            socket = new Socket("127.0.0.1", 5000); // Socket 연결 개체 생성(서버 주소, 포트)
            in = new BufferedReader(new InputStreamReader(socket.getInputStream())); // 입력 처리 개체
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())); // 출력 처리 개체
            while(true){
                System.out.print("보내기>>"); //
                String outMsg = scanner.nextLine(); // 보낼 데이터 입력 대기 처리
                if(outMsg.equalsIgnoreCase("bye")){
                    out.write(outMsg + "\n"); // 연결 해제 메시지 서버에 전송
                    out.flush(); //out 스트림 버퍼에 있는 모든 문자열 비우기.
                    break;
                }
                out.write(outMsg + "\n"); // 입력 받은 데이터 서버에 전송
                out.flush(); // out 스트림 버퍼에 있는 모든 문자열 비우기.
                String inMsg = in.readLine(); // 서버로 부터 전송 받은 데이터 한줄 읽기.
                System.out.println("서버 : " + inMsg);
            }
        }catch(IOException ie){
            ie.printStackTrace();
        }finally {
            try{
                scanner.close();
                if(socket != null){
                    socket.close(); // 클라이언트 소켓 닫기
                }
            }catch (Exception ex){
                System.out.println(ex.getMessage());
            }
        }
    }
}