import java.io.IOException;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); // 키보드 입력 개체 생성
        try{
            Socket _connectSoc = new Socket("127.0.0.1", 5000); // 소켓 이용 서버 연결
            while(true){
                System.out.println("보내기 >> ");
                String outMsg = input.nextLine();
                byte[] buffer = outMsg.getBytes(StandardCharsets.UTF_8); // 입력된 데이터 byte로 변환(인코딩 UTF-8)
                OutputStream outStream = _connectSoc.getOutputStream(); // 소켓 출력 스트림 연결 개체 연결
                outStream.write(buffer); // 소켓 출력 개체를 통해 서버로 전송
            }
        }catch(ConnectException ce){
            System.out.println(ce.getMessage());
        }catch(IOException ie){
            System.out.println(ie.getMessage());
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
}