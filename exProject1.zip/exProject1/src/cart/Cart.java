package cart;

import bookitem.Book;

import java.util.ArrayList;

public class Cart implements CartInterface {
    public ArrayList<CartItem> mCartItem = new ArrayList<CartItem>();
    public static int mCartCount = 0;
    public Cart(){
    }
    @Override
    public void printBookList(ArrayList<Book> booklist) {
        for (int i = 0; i < booklist.size(); i++) {
            Book bookitem = booklist.get(i);
            System.out.print(bookitem.getBookId() + " | ");
            System.out.print(bookitem.getName() + " | ");
            System.out.print(bookitem.getUintPrice() + " | ");
            System.out.print(bookitem.getAuthor() + " | ");
            System.out.print(bookitem.getDescription() + " | ");
            System.out.print(bookitem.getCategory() + " | ");
            System.out.print(bookitem.getReleaseDate());
            System.out.println("");
        }
    }
    @Override
    public boolean isCartInBook(String id) {
        boolean flag = false;
        for (int i = 0; i < mCartItem.size(); i++) {
            if (id.equals(mCartItem.get(i).getBookID())) {
                mCartItem.get(i).setQuantity(mCartItem.get(i).getQuantity() + 1);
                flag = true;
            }
        }
        return flag;
    }
    @Override
    public void insertBook(Book p) {
        CartItem bookitem = new CartItem(p);
        mCartItem.add(bookitem);
        mCartCount = mCartItem.size();
    }
    @Override
    public void removeCart(int numId) {
        mCartItem.remove(numId);
        mCartCount = mCartItem.size();
    }
    @Override
    public void deleteBook() {
        mCartItem.clear();
        mCartCount = 0;
    }

    public void printCart(){
        System.out.println("장바구니 상품 목록:");
        System.out.println("-----------------------------------------");
        System.out.println("    도서ID \t|    수량 \t|      합계");
        for (int i = 0; i < mCartItem.size(); i++) { // 13
            System.out.print("    " + mCartItem.get(i).getBookID() + " \t| ");
            System.out.print("    " + mCartItem.get(i).getQuantity() + " \t| ");
            System.out.print("    " + mCartItem.get(i).getTotalPrice());
            System.out.println("  ");
        }
        System.out.println("-----------------------------------------");
    }
}
